/*
 * compiler/back_ends/idl_gen/gen_any.h
 *
 * MS 92
 * Copyright (C) 1991, 1992 Michael Sample
 *           and the University of British Columbia
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * $Header: /usr/app/odstb/CVS/snacc/compiler/back-ends/idl-gen/gen-any.h,v 1.1 1997/01/01 20:25:33 rj Exp $
 * $Log: gen-any.h,v $
 * Revision 1.1  1997/01/01 20:25:33  rj
 * first draft
 *
 */

void PrintIDLAnyCode PROTO ((FILE *src, IDLRules *r, ModuleList *mods, Module *m));
