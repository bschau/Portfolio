#define VERSION		"1.3"
#define RELDATE		"1997-10-20"
#define BUGREPADDR	"snacc@cs.ubc.ca"
